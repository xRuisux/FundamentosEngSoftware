<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include("conexao.php");
$pessoa = selectIdPessoa($_POST["id"]);
//var_dump($pessoa);
?>
<meta charset="UTF-8">
<form name="dadosUsuario" action="conexao.php" method="POST">
    <style>
        body{
            background-image:url(drone.jpg);
            background-attachment:fixed;
            background-size:100%;
            background-repeat:no-repeat;
            background-color:#000;
        }         
    </style>
    <table border="1" bgcolor="WHITE" align="center">
        <tbody>
        
            <tr>
                <td><font size="3">Nome:</font></td>
                <td><input type="text" name="nome" value="<?=$pessoa["nome"]?>" size="20" /></td>
            </tr>
            <tr>
                <td>CPF:</td>
                <td><input type="text" name="cpf" value="<?=$pessoa["cpf"]?>" size="20"/></td>
            </tr>
            <tr>
                <td>Modelo:</td>
                <td><input type="text" name="modelo" value="<?=$pessoa["modelo"]?>" size="20"/></td>
            </tr>
            <tr>
                <td>Endereço:</td>
                <td><input type="text" name="endereco" value="<?=$pessoa["endereco"]?>" size="20"/></td>
            </tr>
            <tr>
                <td>Telefone:</td>
                <td><input type="text" name="telefone" value="<?=$pessoa["telefone"]?>" size="20"/></td>
            </tr>
            <tr>
                <td><input type="hidden" name="acao" value="alterar" />
                    <input type="hidden" name="id" value="<?=$pessoa["id"]?>" />
                </td>
                <td><input type="submit" value="Enviar" /></td>
            </tr>
            
        </tbody>
        </font>
    </table>

</form>

