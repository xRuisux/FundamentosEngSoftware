<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php include("conexao.php");
        $grupo = selectAllPessoa();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    <style>
        body{
            background-image:url(drone.jpg);
            background-attachment:fixed;
            background-size:100%;
            background-repeat:no-repeat;
            background-color:#000;
        }         
    </style>
    </head>
    <body>
        <div style="text-align:center" style="color: #FFFFFF" >
            <h1><font size="8">Projeto DCMB (Don't Crash Me Bro)</font></h1>
        <a href="inserir.php" style="color: #FFFFFF"><font size="5">Criar Perfil<br><br></font> </a>
        </div>
        <table cellpadding="10" border="10"  bgcolor="WHITE" align="center" >
            <thead>
                <tr>
                    <th>Nome:</th>
                    <th>CPF:</th>
                    <th>Modelo:</th>
                    <th>Endereço:</th>
                    <th>Telefone:</th>
                    <th>Editar</th>
                    <th>Excluir</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach ($grupo as $listausuarios){ ?>
                    <tr>
                    <td><?=$listausuarios["nome"]?></td>
                    <td><?=$listausuarios["cpf"]?></td>
                    <td><?=$listausuarios["modelo"]?></td>
                    <td><?=$listausuarios["endereco"]?></td>
                    <td><?=$listausuarios["telefone"]?></td>
                    <td>
                        <form name="alterar" action="alterar.php" method="POST">
                            <input type="hidden" name="id" value=<?=$listausuarios["id"]?> />
                            <input type="submit" value="Editar" name="editar" />
                            </form>
                    </td>
                    <td>
                        <form name="excluir" action="conexao.php" method="POST">
                            <input type="hidden" name="id" value="<?=$listausuarios["id"]?>" />
                            <input type="hidden" name="acao" value="excluir" />
                            <input type="submit" value="Excluir" name="excluir" />
                            </form>
                    </td>
                    </tr>
                    <?php } 
                ?>
            </tbody>
        </table>

        <?php
        // put your code here
        ?>
    </body>
</html>
