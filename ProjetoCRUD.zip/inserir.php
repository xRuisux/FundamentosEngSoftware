<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */?>
<meta charset="UTF-8">
<form name="dadosUsuario" action="conexao.php" method="POST">
    <style>
        body{
            background-image:url(drone.jpg);
            background-attachment:fixed;
            background-size:100%;
            background-repeat:no-repeat;
            background-color:#000;
        }         
    </style>
    <h1><font size="8"><br><br></font></h1>
    <table border="1" bgcolor="WHITE" align="center">
        <tbody>
            <tr>
                <td>Nome:</td>
                <td><input type="text" name="nome" value="" /></td>
            </tr>
            <tr>
                <td>CPF:</td>
                <td><input type="text" name="cpf" value="" /></td>
            </tr>
            <tr>
                <td>Modelo:</td>
                <td><input type="text" name="modelo" value="" /></td>
            </tr>
            <tr>
                <td>Endereço:</td>
                <td><input type="text" name="endereco" value="" /></td>
            </tr>
            <tr>
                <td>Telefone:</td>
                <td><input type="text" name="telefone" value="" /></td>
            </tr>
            <tr>
                <td><input type="hidden" name="acao" value="inserir" /></td>
                <td><input type="submit" value="Enviar" /></td>
            </tr>
        </tbody>
    </table>

</form>

